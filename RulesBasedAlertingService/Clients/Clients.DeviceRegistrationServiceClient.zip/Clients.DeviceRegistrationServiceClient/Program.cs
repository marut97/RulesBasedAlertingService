﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using Models.Device;

namespace Clients.DeviceRegistrationServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            RunAsync().Wait();
        }
        static async Task RunAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:51033/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Console.WriteLine("Get");
                HttpResponseMessage response = await client.GetAsync("ReadDevice/D103");
                if(response.IsSuccessStatusCode)
                {
                    Device device=await response.Content.ReadAsAsync<Device>();
                    Console.WriteLine(device.DeviceId);
                    Console.WriteLine(device.MaxInputValue);
                }
            }
        }
    }
}
